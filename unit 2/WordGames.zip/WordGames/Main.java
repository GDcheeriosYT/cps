class Main {
    public static void main(String[] args) {

        WordGames aWord = new WordGames("joemama");

        System.out.print(aWord);

    }
}